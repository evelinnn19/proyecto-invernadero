package com.sistdist.servidorexclusionmutua;

import com.sistdist.interfaces.IClienteEM;
import com.sistdist.interfaces.IServicioExclusionMutua;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayDeque;
import java.util.Queue;

/**
 * Servidor de exclusión mutua mejorado con identificación.
 */
public class ServerExclusionMutuaRMI extends UnicastRemoteObject implements IServicioExclusionMutua {

    boolean token;
    Queue<IClienteEM> clientes;
    String nombreServidor;
    int idServidor;
    DetectorFallo detector;
    private volatile boolean maestroCaidoDetectado = false;
    
    public ServerExclusionMutuaRMI() throws RemoteException {
        super();
        token = true;
        clientes = new ArrayDeque<>();
        nombreServidor = "Desconocido";
    }
    
    public void setNombreServidor(String nombre) {
        this.nombreServidor = nombre;
    }
    
    @Override
    public synchronized void ObtenerRecurso(IClienteEM cliente) throws RemoteException {
        System.out.println("[" + nombreServidor + "] Solicitud de recurso recibida");
        
        if (token) {
            token = false;
            cliente.RecibirToken();
            System.out.println("[" + nombreServidor + "] Token entregado inmediatamente");
        } else {
            clientes.add(cliente);
            System.out.println("[" + nombreServidor + "] Cliente encolado. Cola: " + clientes.size());
        }
    }

    @Override
    public synchronized void DevolverRecurso() throws RemoteException {
        System.out.println("[" + nombreServidor + "] Recurso devuelto");
        
        if (!clientes.isEmpty()) {
            IClienteEM cliente = clientes.poll();
            cliente.RecibirToken();
            System.out.println("[" + nombreServidor + "] Token entregado al siguiente cliente. Cola: " + clientes.size());
        } else {
            token = true;
            System.out.println("[" + nombreServidor + "] Token libre (sin clientes esperando)");
        }
    }

    public int getIdServidor() {
        return idServidor;
    }

    public void setIdServidor(int idServidor) {
        this.idServidor = idServidor;
    }

    public DetectorFallo getDetector() {
        return detector;
    }

    public void setDetector(DetectorFallo detector) {
        this.detector = detector;
    }

// Líneas 35-47 del artefacto
@Override
public int notificarFalloYSolicitarVoto() throws RemoteException {
    System.out.println("Notificación de fallo recibida. Verificando...");
    
    if (detector != null && detector.maestroCaido()) {
        maestroCaidoDetectado = true;
        System.out.println("Confirmo el fallo. Participando en elección con ID " + idServidor);
        return idServidor;
    } else {
        System.out.println("No he detectado fallo del maestro. No participo.");
        return -1;
    }
}

@Override
public void anunciarNuevoMaestro(int idNuevoMaestro) throws RemoteException {
    System.out.println("NUEVO MAESTRO ANUNCIADO: ID " + idNuevoMaestro);
    
    
    if (idNuevoMaestro == this.idServidor) {
        System.out.println("SOY EL NUEVO MAESTRO");
        this.nombreServidor = "ServidorMaestro";
    } else {
        System.out.println("Nuevo maestro es servidor ID " + idNuevoMaestro);
    }
    
    maestroCaidoDetectado = false;
}



@Override
public boolean estoyVivo() throws RemoteException {
    return true;
}
    
    
}

